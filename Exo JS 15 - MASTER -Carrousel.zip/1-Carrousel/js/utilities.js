
/*******************************************************************************************/
/* ******************************** FONCTIONS UTILITAIRES **********************************/
/*******************************************************************************************/

function getRandomInteger(min, max)
{
	return Math.floor(Math.random() * (max - min + 1)) + min;
}

function installEventHandler(selector, type, eventHandler)
{
    // Récupération du premier objet DOM correspondant au sélecteur.
    const domObject = document.querySelector(selector)
    // Installation d'un gestionnaire d'évènement sur cet objet DOM.
    domObject.addEventListener(type, eventHandler)
}

/*FONCTION me permet vraiment d'isoler un block de code javascript dans le but d'éviter de recréer ce morceau de code un peu partout dans notre page.
Cela nous permet d'économiser un certain nombre de ligne, d'avoir un code plus propre et d'éviter le code récurant.
On choisit d'utiliser une fonction dans le cas où on voudra réutiliser un bloc de code à plusieurs reprise.
Le fait d'utiliser deds arguments, nous permet de pouvoir customiser et automatiser cette fonction pour plusieurs différents qui auraient besoin du même code mais pour des valeurs différentes
*/

/*let var1 = document.querySelector("blabla")
var1.addEventListener("click", callback)

function callback(){
    console.log("coucou")
}

let var2 = document.querySelector("blabla2")
var2.addEventListener("change", callback1)

function callback1(){
    console.log("coucou")
}


let var3 = document.querySelector("blabla3")
var3.addEventListener("submit", callback2)

function callback2(){
    console.log("coucou")
}*/





/*installEventHandler(".blabla", "click", callback)
installEventHandler(".blabla2", "change", callback1)
installEventHandler(".blabla3", "submit", callback2)*/


